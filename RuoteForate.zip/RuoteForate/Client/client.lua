ESX = exports["es_extended"]:getSharedObject()

local notificaInviata = false

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(10)

        local ped = PlayerPedId()
        local veicolo = GetVehiclePedIsIn(ped, true)
        
        if DoesEntityExist(veicolo) then
            local velocitaVeicolo = GetEntitySpeed(veicolo) 

            if IsVehicleTyreBurst(veicolo, 0, true) or
               IsVehicleTyreBurst(veicolo, 1, true) or
               IsVehicleTyreBurst(veicolo, 4, true) or
               IsVehicleTyreBurst(veicolo, 5, true) then
                SetVehicleForwardSpeed(veicolo, Config.Velocita)
                if not notificaInviata then
                    if Config.Notifiche == "okok" then
                        exports['okokNotify']:Alert('RUOTE FORATE', 'Questo veicolo ha le ruote forate!', 5000, 'info', true)
                    elseif Config.Notifiche == "esx" then
                        ESX.ShowNotification("Questo veicolo ha le ruote forate!")
                    end
                    notificaInviata = true
                end
            else
                notificaInviata = false
            end
        end
    end
end)