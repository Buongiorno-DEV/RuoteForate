fx_version 'cerulean'
game 'gta5'

author 'BuongiornoDEV'

client_scripts {
    'Client/client.lua',
    'Shared/config.lua'
}

shared_script {
    'Shared/config.lua'
}

