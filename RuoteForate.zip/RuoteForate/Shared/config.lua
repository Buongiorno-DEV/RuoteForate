Config = {}

Config.Notifiche = "okok"  -- "okok" oppure "esx"

Config.Velocita = 0.0 -- La velocità del veicolo quando le ruote sono forate, ricordati di aggiungere la cifra decimale altrimenti non funzionerà!

return Config