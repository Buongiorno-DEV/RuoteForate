Config = {}

Config.Notifiche = "esx"  -- "okok" oppure "esx"

Config.Velocita = 0.0 -- La velocità del veicolo quando le ruote sono forate, ricordati di aggiungere la cifra decimale altrimenti non funzionerà!

return Config